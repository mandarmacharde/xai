import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

# ---------- data + model (given) ----------
data = pd.read_csv("House_price.csv").drop("Address", axis=1)
X = data.drop("Price", axis=1)
y = data["Price"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# ---------- helpers  (YOU WRITE THESE) ----------
def partial_dependence_manual(model, X, feature, n_points=50):
    grid = np.linspace(X[feature].min(), X[feature].max(), n_points)   # 1. values to try
    pd_values = []
    for value in grid:
        X_temp = X.copy()                       # 2. fresh copy of the data
        X_temp[feature] = value                 # 3. force EVERY row to this value
        preds = model.predict(X_temp)           # 4. predict for all rows
        pd_values.append(preds.mean())          # 5. average prediction = PDP point
    return grid, np.array(pd_values)

def sensitivity(model, X, feature, delta):
    original = model.predict(X).mean()          # average prediction now
    X_new = X.copy()
    X_new[feature] = X_new[feature] + delta     # nudge the feature by delta
    new = model.predict(X_new).mean()           # average prediction after the nudge
    change = new - original
    return original, new, change, change / delta     # last one = sensitivity (change per unit)

# ---------- PDP for 4 features (given) ----------
features = ["Avg. Area Income", "House Age", "Number of Rooms", "Area Population"]
plt.figure(figsize=(12, 8))
for i, feature in enumerate(features):
    grid, pdp = partial_dependence_manual(model, X_train, feature)
    plt.subplot(2, 2, i + 1)
    plt.plot(grid, pdp)
    plt.xlabel(feature)
    plt.ylabel("Average Predicted Price")
    plt.title("PDP - " + feature)
    plt.grid(True)
plt.tight_layout()
plt.show()

# ---------- sensitivity (given) ----------
changes = {"Avg. Area Income": 5000, "House Age": 1,
           "Number of Rooms": 1, "Area Population": 5000}
for feature, delta in changes.items():
    original, new, change, sens = sensitivity(model, X_test, feature, delta)
    print(feature, "| change in price:", round(change, 2), "| sensitivity:", round(sens, 4))
