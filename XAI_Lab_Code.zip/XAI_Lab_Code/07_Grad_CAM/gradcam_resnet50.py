import torch
import torch.nn.functional as F
import numpy as np
import cv2
import matplotlib.pyplot as plt
from torchvision import models
from PIL import Image

# ---------- model (given) ----------
weights = models.ResNet50_Weights.DEFAULT
model = models.resnet50(weights=weights).eval()
preprocess = weights.transforms()
categories = weights.meta["categories"]

# ---------- hooks: grab activations + gradients of the last conv block (given) ----------
activations = None
gradients = None

def forward_hook(module, inp, out):
    global activations
    activations = out                     # A^k : feature maps  [1, 2048, h, w]

def backward_hook(module, grad_in, grad_out):
    global gradients
    gradients = grad_out[0]               # d score / d A^k     [1, 2048, h, w]

target_layer = model.layer4
target_layer.register_forward_hook(forward_hook)
target_layer.register_full_backward_hook(backward_hook)

# ---------- helper  (YOU WRITE THIS) ----------
def compute_gradcam(activations, gradients):
    alpha = gradients.mean(dim=(2, 3), keepdim=True)          # 1. average gradient per channel -> weights
    cam = (alpha * activations).sum(dim=1, keepdim=True)      # 2. weighted sum of the feature maps
    cam = F.relu(cam)                                         # 3. keep only positive evidence
    cam = cam.squeeze().detach().cpu().numpy()                # 4. to a 2-D numpy array
    cam = cam - cam.min()                                     # 5. scale to 0..1
    if cam.max() != 0:
        cam = cam / cam.max()
    return cam

# ---------- full pipeline (given) ----------
def grad_cam(image_path):
    image = Image.open(image_path).convert("RGB")
    original = np.array(image)
    x = preprocess(image).unsqueeze(0)

    model.zero_grad()
    output = model(x)                                         # forward pass (hook saves activations)
    pred = output.argmax(dim=1).item()
    output[0, pred].backward()                                # backward pass (hook saves gradients)

    cam = compute_gradcam(activations, gradients)
    cam = cv2.resize(cam, (original.shape[1], original.shape[0]))     # up-size to the image

    heat = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
    heat = cv2.cvtColor(heat, cv2.COLOR_BGR2RGB)
    overlay = cv2.addWeighted(original, 0.55, heat, 0.45, 0)
    return original, heat, overlay, categories[pred]

original, heat, overlay, label = grad_cam("part1.jpg")
plt.subplot(1, 3, 1); plt.imshow(original); plt.title("Original")
plt.subplot(1, 3, 2); plt.imshow(heat); plt.title("Grad-CAM")
plt.subplot(1, 3, 3); plt.imshow(overlay); plt.title(label)
plt.show()
