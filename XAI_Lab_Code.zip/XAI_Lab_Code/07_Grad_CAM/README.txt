Grad CAM
Source: Exp 7 - ResNet-50 (PyTorch)
Pip install: pip install torch torchvision opencv-python pillow numpy matplotlib
Input file needed: part1.jpg (any image)

Note: in the exam prep doc the helper functions were bold (the ones you must write); here they are plain code.
