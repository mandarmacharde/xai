import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.neural_network import MLPClassifier

# ---------- data (given; shortened here - use the full lab list) ----------
train = [("i love this movie", 1), ("great acting and a wonderful story", 1),
         ("a brilliant and moving film", 1), ("i loved the ending", 1),
         ("i hate this movie", 0), ("terrible acting and a boring story", 0),
         ("a dull and awful film", 0), ("i hated the ending", 0)]
texts, labels = zip(*train)

vec = CountVectorizer(binary=True, token_pattern=r"(?u)\b\w+\b")   # keep one-letter words like "i"
Xtr = vec.fit_transform(texts).toarray().astype(float)

clf = MLPClassifier(hidden_layer_sizes=(8,), activation="relu", max_iter=2000, random_state=0)
clf.fit(Xtr, labels)
W1, W2 = clf.coefs_            # W1: (vocab, 8)   W2: (8, 1)
b1, b2 = clf.intercepts_       # b1: (8,)         b2: (1,)

# ---------- helpers  (YOU WRITE THESE) ----------
def forward(x, W1, b1, W2, b2):
    z1 = x @ W1 + b1                    # hidden pre-activation
    a1 = np.maximum(0, z1)              # ReLU
    logit = float(a1 @ W2[:, 0] + b2[0])    # output score (before sigmoid)
    return a1, logit

def lrp(x, W1, b1, W2, b2, eps=0.0):
    a1, logit = forward(x, W1, b1, W2, b2)
    R_output = logit                                   # start: relevance = the output score

    # output -> hidden : share the score according to each unit's contribution a1[k]*W2[k]
    z_hidden = a1 * W2[:, 0]
    R_hidden = z_hidden / (z_hidden.sum() + eps) * R_output

    # hidden -> input : each hidden unit shares ITS relevance among the words
    R_words = np.zeros_like(x)
    for k in range(W1.shape[1]):
        if a1[k] <= 0:                                 # dead ReLU unit: nothing to pass down
            continue
        z_words = x * W1[:, k]                         # contribution of every word to unit k
        R_words += z_words / (z_words.sum() + eps) * R_hidden[k]
    return R_words, R_hidden, logit

def grad_x_input(x, W1, b1, W2, b2):
    z1 = x @ W1 + b1
    mask = (z1 > 0).astype(float)                      # 1 where ReLU is active, else 0
    gradient = W1 @ (mask * W2[:, 0])                  # d(logit)/dx  by the chain rule
    return x * gradient                                # gradient x input

# ---------- experiments (given) ----------
sentence = "i love this movie"
x = vec.transform([sentence]).toarray().astype(float)[0]

R_words, R_hidden, logit = lrp(x, W1, b1, W2, b2, eps=0.0)
print("logit:", logit, "| sum of word relevance:", R_words.sum())     # conservation

W1z, W2z = W1.copy(), W2.copy()
b1z, b2z = np.zeros_like(b1), np.zeros_like(b2)                     # bias-free model
lrp0 = lrp(x, W1z, b1z, W2z, b2z)[0]
gxi = grad_x_input(x, W1z, b1z, W2z, b2z)
for w in sentence.split():
    i = vec.vocabulary_[w]
    print(f"{w:8s} LRP-0 = {lrp0[i]:.4f}   Grad x Input = {gxi[i]:.4f}")  # identical!

for eps in [0, 0.1, 0.5, 1, 2]:
    print("eps", eps, "-> total relevance", round(lrp(x, W1, b1, W2, b2, eps)[0].sum(), 4))
