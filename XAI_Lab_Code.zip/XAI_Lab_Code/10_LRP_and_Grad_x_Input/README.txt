LRP and Grad x Input
Source: Exp 10 - small MLP on movie sentences (NumPy)
Pip install: pip install numpy scikit-learn
Input file needed: (none - data is inside the script)

Note: in the exam prep doc the helper functions were bold (the ones you must write); here they are plain code.
