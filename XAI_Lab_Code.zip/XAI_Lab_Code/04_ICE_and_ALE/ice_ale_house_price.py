import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

# ---------- data + model (given) ----------
data = pd.read_csv("House_price.csv").drop("Address", axis=1)
X = data.drop("Price", axis=1)
y = data["Price"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

feature = "Avg. Area Income"

# ---------- helpers  (YOU WRITE THESE) ----------
def ice_curves(model, X, feature, grid):
    """One row per sample, one column per grid value."""
    curves = []
    for value in grid:
        X_temp = X.copy()
        X_temp[feature] = value                  # set the feature to the grid value for ALL samples
        curves.append(model.predict(X_temp))     # one prediction per sample
    return np.array(curves).T                    # shape: (n_samples, n_grid)

def ale_1d(model, X, feature, n_bins=10):
    bins = np.linspace(X[feature].min(), X[feature].max(), n_bins + 1)   # 1. cut range into bins
    effects, centers = [], []
    for i in range(n_bins):
        lower, upper = bins[i], bins[i + 1]
        if i == n_bins - 1:                                   # last bin includes the right edge
            mask = (X[feature] >= lower) & (X[feature] <= upper)
        else:
            mask = (X[feature] >= lower) & (X[feature] < upper)
        X_bin = X[mask]                                       # 2. ONLY the real rows inside this bin
        if len(X_bin) == 0:
            continue
        X_low, X_up = X_bin.copy(), X_bin.copy()
        X_low[feature] = lower                                # 3. same rows, feature at lower edge
        X_up[feature] = upper                                 #    same rows, feature at upper edge
        diff = model.predict(X_up) - model.predict(X_low)     # 4. local change in prediction
        effects.append(diff.mean())                           # 5. average local effect of this bin
        centers.append((lower + upper) / 2)
    ale = np.cumsum(effects)                                  # 6. accumulate the local effects
    ale = ale - ale.mean()                                    # 7. centre around zero
    return np.array(centers), ale

# ---------- ICE (given) ----------
grid = np.linspace(X_train[feature].min(), X_train[feature].max(), 50)
ice = ice_curves(model, X_test.iloc[:100], feature, grid)
plt.figure(figsize=(10, 6))
for row in ice:
    plt.plot(grid, row, alpha=0.4)
plt.plot(grid, ice.mean(axis=0), "k--", linewidth=3, label="average = PDP")
plt.xlabel(feature); plt.ylabel("Predicted House Price"); plt.title("ICE plot")
plt.legend(); plt.show()

# ---------- ALE (given) ----------
centers, ale = ale_1d(model, X_test, feature, n_bins=10)
plt.figure(figsize=(10, 6))
plt.plot(centers, ale, marker="o")
plt.axhline(0, linestyle="--")
plt.xlabel(feature); plt.ylabel("Centered ALE"); plt.title("ALE plot")
plt.grid(True); plt.show()
