ICE and ALE
Source: Exp 4 - House price, Random Forest regressor
Pip install: pip install numpy pandas matplotlib scikit-learn
Input file needed: House_price.csv

Note: in the exam prep doc the helper functions were bold (the ones you must write); here they are plain code.
