LIME Text
Source: Exp 9 - DistilBERT SST-2, lime_text
Pip install: pip install torch transformers lime numpy
Input file needed: (none - model downloads from Hugging Face)

Note: in the exam prep doc the helper functions were bold (the ones you must write); here they are plain code.
