import re
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from lime.lime_text import LimeTextExplainer

# ---------- model (given) ----------
MODEL_NAME = "distilbert/distilbert-base-uncased-finetuned-sst-2-english"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME).eval()

print(model.config.id2label)                  # {0: 'NEGATIVE', 1: 'POSITIVE'}
NEG, POS = 0, 1

# ---------- helpers  (YOU WRITE THESE) ----------
def predict_proba(sentences):
    """LIME passes a LIST of strings. Return array (n_sentences, 2) of probabilities."""
    if isinstance(sentences, str):
        sentences = [sentences]
    enc = tokenizer(sentences, padding=True, truncation=True, return_tensors="pt")
    with torch.no_grad():
        logits = model(**enc).logits
    return torch.softmax(logits, dim=1).numpy()

def get_words(sentence):
    return re.findall(r"\b[\w'-]+\b", sentence)            # words without punctuation

def remove_one_word(sentence):
    words = get_words(sentence)
    original = predict_proba([sentence])[0][POS]            # positive probability now
    rows = []
    for i, w in enumerate(words):
        shorter = " ".join(words[:i] + words[i + 1:])       # sentence WITHOUT word i
        p = predict_proba([shorter])[0][POS]
        rows.append((w, p, original - p))                   # drop > 0  => word was pushing POSITIVE
    return sorted(rows, key=lambda r: r[2], reverse=True)

def find_removed_words(original, changed):
    orig_words, changed_words = get_words(original), get_words(changed)
    removed, j = [], 0
    for w in orig_words:
        if j < len(changed_words) and w.lower() == changed_words[j].lower():
            j += 1                                          # word is still there
        else:
            removed.append(w)                               # word disappeared
    return removed

# ---------- run LIME (given) ----------
sentence = "The plot was weak, but the acting was wonderful."
print(predict_proba([sentence]))

generated = []                                              # remember every sentence LIME tries
def lime_fn(sentences):
    generated.extend(sentences)
    return predict_proba(sentences)

explainer = LimeTextExplainer(class_names=["NEGATIVE", "POSITIVE"], random_state=42)
exp = explainer.explain_instance(sentence, lime_fn,
                                 num_features=len(sentence.split()), num_samples=1000)
scores = exp.as_list()                                      # [(word, score), ...]
print(scores)
print("largest +:", max(scores, key=lambda s: s[1]), " largest -:", min(scores, key=lambda s: s[1]))

# ---------- the 3 lowest copies and what they removed (given) ----------
unique = [s for s in dict.fromkeys(generated) if s != sentence]
pos_prob = predict_proba(unique)[:, POS]
for idx in np.argsort(pos_prob)[:3]:
    print(unique[idx], "->", pos_prob[idx], "removed:", find_removed_words(sentence, unique[idx]))

# ---------- remove-one-word vs LIME (given) ----------
for w, p, drop in remove_one_word(sentence):
    print(f"{w:12s} P(pos)={p:.3f} drop={drop:+.3f}")

# ---------- 100 samples vs 1000 samples (given) ----------
exp100 = explainer.explain_instance(sentence, predict_proba,
                                    num_features=len(sentence.split()), num_samples=100)
print(exp100.as_list())
