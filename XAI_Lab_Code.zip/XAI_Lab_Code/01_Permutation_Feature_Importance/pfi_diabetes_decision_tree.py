import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.inspection import permutation_importance

# ---------- data + model (given) ----------
df = pd.read_csv("diabetes.csv")
X = df.drop("Outcome", axis=1)
y = df["Outcome"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

model = DecisionTreeClassifier(criterion="entropy", max_depth=5, random_state=42)
model.fit(X_train, y_train)

# ---------- library PFI (given) ----------
result = permutation_importance(model, X_test, y_test, scoring="accuracy",
                                n_repeats=10, random_state=42)

# ---------- manual PFI  (YOU WRITE THIS) ----------
def manual_pfi(model, X, y, n_repeats=1):
    baseline = accuracy_score(y, model.predict(X))      # 1. score BEFORE shuffling
    importance = []
    for feature in X.columns:                            # 2. one feature at a time
        drops = []
        for _ in range(n_repeats):
            X_perm = X.copy()                            # 3. copy, keep original safe
            X_perm[feature] = np.random.permutation(X_perm[feature].values)  # 4. shuffle ONE column
            score = accuracy_score(y, model.predict(X_perm))   # 5. score AFTER shuffling
            drops.append(baseline - score)               # 6. importance = how much accuracy fell
        importance.append(np.mean(drops))
    return importance

manual = manual_pfi(model, X_test, y_test)

# ---------- compare + plot (given) ----------
comparison = pd.DataFrame({"Feature": X.columns,
                           "Library_PFI": result.importances_mean,
                           "Manual_PFI": manual}).sort_values("Library_PFI", ascending=False)
print(comparison)
comparison.plot(x="Feature", y=["Library_PFI", "Manual_PFI"], kind="bar")
plt.ylabel("Permutation Importance")
plt.show()
