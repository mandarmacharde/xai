Integrated Gradients
Source: Exp 5 - ResNet-18, Captum
Pip install: pip install torch torchvision captum pillow numpy
Input file needed: dog.jpg (any image)

Note: in the exam prep doc the helper functions were bold (the ones you must write); here they are plain code.
