import torch
import torch.nn.functional as F
import numpy as np
from torchvision import models, transforms
from PIL import Image, ImageFilter
from captum.attr import IntegratedGradients

# ---------- model + image (given) ----------
MEAN = [0.485, 0.456, 0.406]
STD = [0.229, 0.224, 0.225]

model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT).eval()
preprocess = transforms.Compose([
    transforms.Resize(256), transforms.CenterCrop(224),
    transforms.ToTensor(), transforms.Normalize(MEAN, STD)])

raw_img = Image.open("dog.jpg").convert("RGB")
x = preprocess(raw_img).unsqueeze(0)                  # shape [1, 3, 224, 224]

probs = F.softmax(model(x), dim=1)
target = probs.argmax(dim=1).item()                   # class we want to explain

# ---------- helpers  (YOU WRITE THESE) ----------
def get_baseline(kind, raw_img, x):
    m = torch.tensor(MEAN).view(1, 3, 1, 1)
    s = torch.tensor(STD).view(1, 3, 1, 1)
    if kind == "black":                               # pixel value 0, written in normalised units
        return (torch.zeros_like(x) - m) / s
    if kind == "white":                               # pixel value 1
        return (torch.ones_like(x) - m) / s
    if kind == "blur":                                # blurred copy of the same image
        return preprocess(raw_img.filter(ImageFilter.GaussianBlur(15))).unsqueeze(0)

def integrated_gradients(model, x, baseline, target, steps=50):
    total_grad = torch.zeros_like(x)
    for k in range(1, steps + 1):
        point = baseline + (k / steps) * (x - baseline)     # a point on the straight path
        point = point.clone().requires_grad_(True)
        score = model(point)[0, target]                     # class score (logit, before softmax)
        grad = torch.autograd.grad(score, point)[0]         # d score / d pixels
        total_grad += grad
    avg_grad = total_grad / steps                           # Riemann-sum average of the gradients
    return (x - baseline) * avg_grad                        # scale by how far the input moved

def hide_top_pixels(x, attr, k_percent):
    importance = attr.abs().sum(dim=1)                      # one number per pixel: [1, H, W]
    threshold = torch.quantile(importance.flatten(), 1 - k_percent / 100)
    mask = (importance >= threshold).float().unsqueeze(1)   # 1 = top-k% pixels, shape [1,1,H,W]
    return x * (1 - mask)                                   # set those pixels to 0

# ---------- run IG (given) ----------
baseline = get_baseline("black", raw_img, x)

attr_manual = integrated_gradients(model, x, baseline, target, steps=50)

ig = IntegratedGradients(model)                             # library version (same maths)
attr, delta = ig.attribute(x, baselines=baseline, target=target,
                           n_steps=50, return_convergence_delta=True)

# completeness check: sum of attributions = F(x) - F(baseline)
with torch.no_grad():
    diff = model(x)[0, target] - model(baseline)[0, target]
print(attr_manual.sum().item(), diff.item(), "delta:", delta.item())

# ---------- deletion test (given) ----------
x_hidden = hide_top_pixels(x, attr, k_percent=15)
with torch.no_grad():
    new_conf = F.softmax(model(x_hidden), dim=1)[0, target].item()
print("confidence:", probs[0, target].item(), "->", new_conf)
