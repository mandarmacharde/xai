XRAI and Gray Patch
Source: Exp 6 - InceptionV3 (TensorFlow), saliency library
Pip install: pip install tensorflow saliency pillow numpy matplotlib
Input file needed: cat.jpg (any image)

Note: in the exam prep doc the helper functions were bold (the ones you must write); here they are plain code.
