import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import saliency.core as saliency
from PIL import Image
from tensorflow.keras.applications import InceptionV3
from tensorflow.keras.applications.inception_v3 import preprocess_input
from tensorflow.keras.applications.imagenet_utils import decode_predictions

# ---------- model + image (given) ----------
model = InceptionV3(weights="imagenet", include_top=True)

image = np.array(Image.open("cat.jpg").convert("RGB").resize((299, 299))).astype(np.float32)
input_image = preprocess_input(image.copy())

pred = model.predict(np.expand_dims(input_image, 0), verbose=0)[0]
target_class = int(np.argmax(pred))
original_conf = float(pred[target_class])
print(decode_predictions(np.expand_dims(pred, 0), top=3)[0])

# ---------- helper 1 for XRAI  (YOU WRITE THIS) ----------
def call_model_function(images, call_model_args=None, expected_keys=None):
    images = tf.convert_to_tensor(images, dtype=tf.float32)
    target = call_model_args["target_class"]
    with tf.GradientTape() as tape:
        tape.watch(images)                                  # track gradients w.r.t. the pixels
        output = model(images, training=False)[:, target]   # score of the target class
    gradients = tape.gradient(output, images).numpy()       # d score / d pixels
    return {saliency.INPUT_OUTPUT_GRADIENTS: gradients}     # XRAI expects exactly this key

# ---------- run XRAI (given) ----------
xrai = saliency.XRAI()
mask = xrai.GetMask(input_image, call_model_function,
                    call_model_args={"target_class": target_class})
mask = np.array(mask)
if mask.ndim == 3:
    mask = mask.mean(axis=-1)
mask = (mask - mask.min()) / (mask.max() - mask.min())      # scale to 0..1
top20 = mask >= np.percentile(mask, 80)                     # the most important 20 %

plt.subplot(1, 2, 1); plt.imshow(image.astype(np.uint8)); plt.title("Original")
plt.subplot(1, 2, 2); plt.imshow(image.astype(np.uint8)); plt.imshow(mask, cmap="jet", alpha=0.45)
plt.title("XRAI overlay"); plt.show()

# ---------- helper 2 and 3: gray-patch test  (YOU WRITE THESE) ----------
def create_patched_image(image, x, y, size):
    patched = image.copy()
    half = size // 2
    x1, x2 = max(0, x - half), min(299, x + half)           # keep the box inside the image
    y1, y2 = max(0, y - half), min(299, y + half)
    patched[y1:y2, x1:x2] = 128                             # paint a gray square
    return patched

def find_worst_patch(image, sizes=(30, 50, 70, 90), step=30):
    candidates, batch = [], []
    for size in sizes:
        for y in range(30, 270, step):
            for x in range(30, 270, step):
                candidates.append((x, y, size))
                batch.append(preprocess_input(create_patched_image(image, x, y, size).copy()))
    preds = model.predict(np.array(batch), verbose=0)[:, target_class]   # confidence for every patch
    drops = original_conf - preds                           # how much confidence was lost
    best = int(np.argmax(drops))                            # patch that hurts the most
    return candidates[best], drops[best]

(bx, by, bsize), best_drop = find_worst_patch(image)
print("worst patch at", (bx, by), "size", bsize, "| confidence drop:", best_drop)
plt.imshow(create_patched_image(image, bx, by, bsize).astype(np.uint8)); plt.show()
