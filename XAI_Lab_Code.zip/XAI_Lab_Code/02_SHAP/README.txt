SHAP
Source: Exp 2 - Breast Cancer, Random Forest
Pip install: pip install numpy pandas matplotlib scikit-learn shap
Input file needed: (built-in sklearn dataset)

Note: in the exam prep doc the helper functions were bold (the ones you must write); here they are plain code.
