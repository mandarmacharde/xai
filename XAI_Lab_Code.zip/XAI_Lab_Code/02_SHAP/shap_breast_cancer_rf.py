import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shap
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

# ---------- data + model (given) ----------
data = load_breast_cancer()
X = pd.DataFrame(data.data, columns=data.feature_names)
y = pd.Series(data.target)          # 0 = malignant, 1 = benign
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# ---------- SHAP values (given) ----------
explainer = shap.TreeExplainer(model)
raw_shap = explainer.shap_values(X_test)

# ---------- helpers  (YOU WRITE THESE) ----------
def get_class_shap(raw_shap, class_id=1):
    """Different SHAP versions return different shapes. Make it (samples x features)."""
    if isinstance(raw_shap, list):               # old SHAP: [class0_array, class1_array]
        return np.asarray(raw_shap[class_id])
    raw_shap = np.asarray(raw_shap)
    if raw_shap.ndim == 3:                       # new SHAP: (samples, features, classes)
        return raw_shap[:, :, class_id]
    return raw_shap                              # already 2-D

def shap_importance(shap_vals, feature_names):
    mean_abs = np.abs(shap_vals).mean(axis=0)    # average |SHAP| over all samples
    table = pd.DataFrame({"Feature": feature_names, "Mean |SHAP|": mean_abs})
    return table.sort_values("Mean |SHAP|", ascending=False)

shap_vals = get_class_shap(raw_shap, class_id=1)
base_value = np.ravel(explainer.expected_value)[1]    # average prediction for class 1

# ---------- global plots (given) ----------
shap.summary_plot(shap_vals, X_test)                      # beeswarm
shap.summary_plot(shap_vals, X_test, plot_type="bar")     # bar
print(shap_importance(shap_vals, X_test.columns).head(10))

# ---------- local plots for ONE sample (given) ----------
sample = 10
exp = shap.Explanation(values=shap_vals[sample], base_values=base_value,
                       data=X_test.iloc[sample].values,
                       feature_names=X_test.columns.tolist())
shap.plots.waterfall(exp, max_display=10)

shap.force_plot(base_value, shap_vals[sample], X_test.iloc[sample], matplotlib=True)

# ---------- additivity check: base + sum(SHAP) = model output ----------
print(base_value + shap_vals[sample].sum())
print(model.predict_proba(X_test.iloc[[sample]])[0, 1])
