import numpy as np
import torch
import matplotlib.pyplot as plt
from PIL import Image
from skimage import data, segmentation
from lime import lime_image
from torchvision.models import resnet50, ResNet50_Weights

# ---------- model + image (given) ----------
weights = ResNet50_Weights.DEFAULT
model = resnet50(weights=weights).eval()
preprocess = weights.transforms()
categories = weights.meta["categories"]

img = data.astronaut()                                   # uint8 array (H, W, 3)

# ---------- helpers  (YOU WRITE THESE) ----------
@torch.no_grad()
def classifier_fn(batch):
    """LIME gives a batch of images (numpy). Return class probabilities, shape (n, 1000)."""
    tensors = []
    for im in batch:
        im = np.clip(im, 0, 255).astype(np.uint8)
        tensors.append(preprocess(Image.fromarray(im)))   # same preprocessing as normal
    x = torch.stack(tensors)
    return torch.softmax(model(x), dim=1).numpy()

def slic_segments(im):
    return segmentation.slic(im, n_segments=60, compactness=10, start_label=0, channel_axis=-1)

def quickshift_segments(im):
    return segmentation.quickshift(im, kernel_size=3, max_dist=6, ratio=0.5, channel_axis=-1)

def make_explanation(im, segmentation_fn, num_samples=800, seed=42):
    explainer = lime_image.LimeImageExplainer(random_state=seed)
    return explainer.explain_instance(
        im, classifier_fn, top_labels=3, hide_color=0,
        num_samples=num_samples, segmentation_fn=segmentation_fn, random_seed=seed)

def get_positive_weights(explanation, class_id):
    pairs = explanation.local_exp[class_id]                  # [(segment_id, weight), ...]
    positive = [(int(s), float(w)) for s, w in pairs if w > 0]
    return sorted(positive, key=lambda p: p[1], reverse=True)   # strongest first

def deletion_test(im, explanation, class_id, base_prob, k_list=(1, 3, 5, 10), n_random=20):
    segments = explanation.segments
    weights = get_positive_weights(explanation, class_id)
    all_ids = np.unique(segments)
    rng = np.random.default_rng(42)
    results = []
    for k in k_list:
        if len(weights) < k:
            continue
        top_ids = [s for s, w in weights[:k]]                # LIME's k best regions
        deleted = im.copy()
        deleted[np.isin(segments, top_ids)] = 0              # blacken them
        lime_drop = base_prob - classifier_fn([deleted])[0, class_id]

        random_drops = []
        for _ in range(n_random):                            # same number of RANDOM regions
            ids = rng.choice(all_ids, size=k, replace=False)
            d = im.copy()
            d[np.isin(segments, ids)] = 0
            random_drops.append(base_prob - classifier_fn([d])[0, class_id])
        results.append((k, lime_drop, np.mean(random_drops)))
    return results

# ---------- run (given) ----------
probs = classifier_fn([img])[0]
target = int(np.argmax(probs))
print("Prediction:", categories[target], probs[target])

exp_A = make_explanation(img, slic_segments)
exp_B = make_explanation(img, quickshift_segments)

out_A, _ = exp_A.get_image_and_mask(target, positive_only=True, num_features=10, hide_rest=False)
out_B, _ = exp_B.get_image_and_mask(target, positive_only=True, num_features=10, hide_rest=False)
plt.subplot(1, 2, 1); plt.imshow(out_A); plt.title("SLIC")
plt.subplot(1, 2, 2); plt.imshow(out_B); plt.title("Quickshift"); plt.show()

for name, exp in [("SLIC", exp_A), ("Quickshift", exp_B)]:
    print(name)
    for k, lime_drop, rand_drop in deletion_test(img, exp, target, probs[target]):
        print(f"  k={k:2d}  LIME drop={lime_drop:.4f}  random drop={rand_drop:.4f}")
