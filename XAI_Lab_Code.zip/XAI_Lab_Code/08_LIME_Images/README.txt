LIME Images
Source: Exp 8 - ResNet-50, lime_image
Pip install: pip install torch torchvision lime scikit-image pillow numpy matplotlib
Input file needed: (skimage built-in astronaut image)

Note: in the exam prep doc the helper functions were bold (the ones you must write); here they are plain code.
