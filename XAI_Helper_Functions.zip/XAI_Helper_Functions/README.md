# XAI Lab Exam Prep — Extracted Functions

This archive separates the Python functions from the main experiment code in the supplied
**XAI_Lab_Exam_Prep.docx**. Functions are grouped by experiment and each function is in
its own `.py` file.

## Contents

### Exp 01 - Permutation Feature Importance
- `manual_pfi.py`

### Exp 02 - SHAP
- `get_class_shap.py`
- `shap_importance.py`

### Exp 03 - PDP and Sensitivity
- `partial_dependence_manual.py`
- `sensitivity.py`

### Exp 04 - ICE and ALE
- `ice_curves.py`
- `ale_1d.py`

### Exp 05 - Integrated Gradients
- `get_baseline.py`
- `integrated_gradients.py`
- `hide_top_pixels.py`

### Exp 06 - XRAI and Occlusion
- `call_model_function.py`
- `create_patched_image.py`
- `find_worst_patch.py`

### Exp 07 - Grad-CAM
- `forward_hook.py`
- `backward_hook.py`
- `compute_gradcam.py`
- `grad_cam.py`

### Exp 08 - LIME for Images
- `classifier_fn.py`
- `slic_segments.py`
- `quickshift_segments.py`
- `make_explanation.py`
- `get_positive_weights.py`
- `deletion_test.py`

### Exp 09 - LIME for Text
- `predict_proba.py`
- `get_words.py`
- `remove_one_word.py`
- `find_removed_words.py`
- `lime_fn.py`

### Exp 10 - LRP and Gradient x Input
- `forward.py`
- `lrp.py`
- `grad_x_input.py`

## Important notes

- The function bodies are extracted from the document; they are not standalone programs.
- Add the imports used by the relevant experiment notebook before running them.
- Some functions rely on objects defined in the experiment's main code, such as `model`,
  `preprocess`, `target_class`, `original_conf`, `MEAN`, `STD`, or `saliency`.
- `forward_hook` and `backward_hook` are included with Grad-CAM because they are part
  of that experiment's helper/supporting function code. `grad_cam` is also included
  as it appears alongside the Grad-CAM helper.
- No experiment data, model weights, images, or datasets are included.
